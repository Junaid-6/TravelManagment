 import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class LeafletMapDisplay {
	public static void displayAccommodations(ArrayList<Accommodation> accommodations) throws UnsupportedEncodingException {
        // Generate the HTML content for the Leaflet map
        StringBuilder mapHTML = new StringBuilder();
        mapHTML.append("<html><head>")
                .append("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css' />")
                .append("<script src='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js'></script>")
                .append("<style>html, body, #map { height: 100%; margin: 0; padding: 0; }</style>")
                .append("</head><body>")
                .append("<div id='map'></div>")
                .append("<script>")
                .append("var map = L.map('map').setView([51.505, -0.09], 2);")
                .append("L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {")
                .append("  attribution: 'Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors',")
                .append("  maxZoom: 18")
                .append("}).addTo(map);");

        // Create a JavaScript array to store all accommodation markers
        mapHTML.append("var markers = [];");

        // Add markers for each accommodation
        for (Accommodation accommodation : accommodations) {
            String name = URLEncoder.encode(accommodation.getCompanyName(), "UTF-8");
            double latitude = accommodation.getLatitude();
            double longitude = accommodation.getLongitude();

            // Add marker for accommodation
            mapHTML.append("var marker = L.marker([")
                    .append(latitude).append(", ").append(longitude).append("]);")
                    .append("marker.bindTooltip('").append(name).append("', { permanent: true, direction: 'top' }).openTooltip();")
                    .append("markers.push(marker);");
        }

        // Add all markers to the map
        mapHTML.append("var group = L.featureGroup(markers);")
                .append("group.addTo(map);")
                .append("map.fitBounds(group.getBounds());");

        // Close the JavaScript code and HTML tags
        mapHTML.append("</script>")
                .append("</body></html>");

        // Write the HTML content to a file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("map.html"))) {
            writer.write(mapHTML.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Open the generated HTML file in the default web browser
        try {
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                // For Windows
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler map.html");
            } else if (os.contains("mac")) {
                // For Mac OS
                Runtime.getRuntime().exec("open map.html");
            } else if (os.contains("nix") || os.contains("nux") || os.contains("bsd")) {
                // For Linux/Unix
                Runtime.getRuntime().exec("xdg-open map.html");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void displayTicketConnections(List<Ticket> tickets) throws UnsupportedEncodingException {
        // Generate the HTML content for the Leaflet map
        StringBuilder mapHTML = new StringBuilder();
        mapHTML.append("<html><head>")
                .append("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css' />")
                .append("<script src='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js'></script>")
                .append("<style>html, body, #map { height: 100%; margin: 0; padding: 0; }</style>")
                .append("</head><body>")
                .append("<div id='map'></div>")
                .append("<script>")
                .append("var map = L.map('map').setView([51.505, -0.09], 2);")
                .append("L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {")
                .append("  attribution: 'Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors',")
                .append("  maxZoom: 18")
                .append("}).addTo(map);");

        // Add markers and connections for each ticket
        for (Ticket ticket : tickets) {
            String source = URLEncoder.encode(ticket.getFrom(), "UTF-8");
            String destination = URLEncoder.encode(ticket.getTo(), "UTF-8");
            String ticketType = ticket.getType(); // Get the ticket type

            // Add marker for source
            mapHTML.append("var sourceMarker = L.marker([")
                    .append(Double.toString(ticket.getSourceLatitude())).append(", ").append(Double.toString(ticket.getSourceLongitude())).append("]).addTo(map);");

            // Add marker for destination
            mapHTML.append("var destinationMarker = L.marker([")
                    .append(Double.toString(ticket.getDestinationLatitude())).append(", ").append(Double.toString(ticket.getDestinationLongitude())).append("]).addTo(map);");

            // Show names of source and destination markers all the time
            mapHTML.append("sourceMarker.bindTooltip('").append(source).append("', { permanent: true, direction: 'top' }).openTooltip();")
                    .append("destinationMarker.bindTooltip('").append(destination).append("', { permanent: true, direction: 'top' }).openTooltip();");

         // Add polyline to connect source and destination with the ticket type as a label
            mapHTML.append("var polyline = L.polyline([[")
                    .append(Double.toString(ticket.getSourceLatitude())).append(", ").append(Double.toString(ticket.getSourceLongitude())).append("], [")
                    .append(Double.toString(ticket.getDestinationLatitude())).append(", ").append(Double.toString(ticket.getDestinationLongitude()))
                    .append("]]).addTo(map);")
                    .append("polyline.bindTooltip('").append(ticketType).append("', { permanent: true, direction: 'center', className: 'ticket-label' }).openTooltip();");

            // Add CSS style for the ticket label
            mapHTML.append("var ticketLabelStyle = document.createElement('style');")
                    .append("ticketLabelStyle.innerHTML = '.ticket-label {")
                    .append("  background-color: #fff;")
                    .append("  border: 1px solid #999;")
                    .append("  padding: 4px;")
                    .append("  font-size: 12px;")
                    .append("  font-weight: bold;")
                    .append("  text-align: center;")
                    .append("}';")
                    .append("document.head.appendChild(ticketLabelStyle);");

        }
        // Close the JavaScript code and HTML tags
        mapHTML.append("</script>")
                .append("</body></html>");

        // Write the HTML content to a file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("map.html"))) {
            writer.write(mapHTML.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Open the generated HTML file in the default web browser
        try {
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                // For Windows
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler map.html");
            } else if (os.contains("mac")) {
                // For Mac OS
                Runtime.getRuntime().exec("open map.html");
            } else if (os.contains("nix") || os.contains("nux") || os.contains("bsd")) {
                // For Linux/Unix
                Runtime.getRuntime().exec("xdg-open map.html");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
