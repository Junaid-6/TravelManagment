import java.util.ArrayList;

public class Accommodation extends Ticket
{
	protected static int MAX_NUM_TOURS = 3; // maximum number of tours defined by the hotel regulation bodies	 
	protected String city;  // city of the accommodation
	protected int numberBeds = 0; // number of beds
	protected boolean hasAccessibility;
	protected Point location;
	protected ArrayList <Ticket> ticketTourList;
	public ArrayList<Client> clientData = new ArrayList<Client>();
	

	public Accommodation(int c, String cn, String em, String t, double p, String ct, int nb, Double lat, Double lng ) {
		super(c,cn,em,t,p,null,null,0);
		this.code = c;
		this.companyName = cn;
		this.email = em;
		this.type = t;
		this.price = p; 
		this.city = ct;
		this.numberBeds = nb;	
		this.location = new Point(lat,lng,cn);
	} 
	public boolean getAccessibility() {
		return this.hasAccessibility;
	}
	public void setAccessibility(boolean allowed) {
		this.hasAccessibility = allowed;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getNumberBeds() {
		return numberBeds;
	}
	public void setNumberBeds(int numberBeds) {
		this.numberBeds = numberBeds;
	}
	public double getLatitude() {
		return this.location.getLatitude();
	}
	public double getLongitude() {
		return this.location.getLongitude();
	}

	public boolean addTour(Ticket d) {
		if(this.numberBeds <= MAX_NUM_TOURS) {
			for(Ticket t : ticketTourList)
				if(t.equals(d) && t.companyName == d.companyName)
					return false;
			ticketTourList.add(d);
			this.setNumberBeds(this.getNumberBeds()+1);
			return true;
		}
		return false;
	}
	public boolean removeTour(Ticket d) {
		for(int i = 0; i < ticketTourList.size(); i++) {
			if (d.equals(ticketTourList.get(i)) && d.companyName == ticketTourList.get(i).companyName) {
				ticketTourList.remove(d);
				return true;
			}
		}
		return false;
	}
	public ArrayList<Ticket> getTicketList(){
		return this.ticketTourList;
	}
	public Accommodation getAccommodation() {
		return this;
	}
	 
	public String toString() {
		return "Accommodation: Name: " + companyName + "- Price: " + price;
	}
	public ArrayList<Client> getClient(){
		return this.clientData;
	}
	public boolean bookbed(String name, String email, String phone) {
		 
		clientData.add(new Client( name, email, phone));
		 
		return true;
	}
}
