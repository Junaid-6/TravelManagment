import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;

public class GUI extends JFrame {
    TravelManager manager;

    private JTable table;
    JFrame frame = new JFrame();
    public GUI(TravelManager Manager) {
        this.manager = Manager;
        setSize(800, 600);
        setLocationRelativeTo(null);
    }
    public void displayData(Object[][] rowData, String[] columnNames, String title, ListSelectionListener listener) {
        setTitle(title);
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);

        DefaultTableModel tableModel = new DefaultTableModel(rowData, columnNames);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(800, 500)); // Increase the size of the scroll pane
        contentPane.add(scrollPane);

        adjustColumnWidths(table);
        table.getSelectionModel().addListSelectionListener(listener);
        setVisible(true);
    }
    public void displayAccommodations(Accommodation[] accommodations) {
        String[] columnNames = {"ID", "Hotel Name", "Email", "Type", "Price/Hour", "Location", "Rating"};
        Object[][] rowData = new Object[accommodations.length][columnNames.length];
        for (int i = 0; i < accommodations.length; i++) {
            Accommodation accommodation = accommodations[i];
            rowData[i] = new Object[]{accommodation.getCode(), accommodation.getCompanyName(), accommodation.getEmail(),
                    accommodation.getType(), accommodation.getPrice(), accommodation.getCity(), accommodation.getNumberBeds()};
        }

        displayData(rowData, columnNames, "Accommodation List", new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
            	 onRowSelected("Accommodation");
            }
        });
    }

    public void displayTickets(Ticket[] tickets) {
        String[] columnNames = {"ID", "Airline", "Email", "Type", "Price", "Source", "Destination", "Duration"};
        Object[][] rowData = new Object[tickets.length][columnNames.length];
        for (int i = 0; i < tickets.length; i++) {
            Ticket ticket = tickets[i];
            rowData[i] = new Object[]{ticket.getCode(), ticket.getCompanyName(), ticket.getEmail(), ticket.getType(),
                    ticket.getPrice(), ticket.getFrom(), ticket.getTo(), ticket.getDuration()};
        }

        displayData(rowData, columnNames, "Ticket List", new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
            	 onRowSelected("Ticket");
            }
        });
    } 
    public void displayClients(ArrayList<Client> arrayList) {
    	String[] columnNames = {"Name","Email","Phone"};
    	Object[][] rowData = new Object[arrayList.size()][columnNames.length];
    	for(int i = 0; i < arrayList.size(); i++) {
    		Client client = arrayList.get(i);
    		rowData[i] = new Object[] {	client.name,client.email, client.phone};
    	}
    	displayData(rowData, columnNames, "Client Data List", new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
            	// onRowSelected("Client");
            }
        });
    }

    private void adjustColumnWidths(JTable table) {
        TableColumnModel columnModel = table.getColumnModel();
        for (int columnIndex = 0; columnIndex < table.getColumnCount(); columnIndex++) {
            TableColumn column = columnModel.getColumn(columnIndex);
            int preferredWidth = 0;
            int maxWidth = column.getMaxWidth();
            // Calculate preferred width based on header
            TableCellRenderer headerRenderer = column.getHeaderRenderer();
            if (headerRenderer == null) {
                headerRenderer = table.getTableHeader().getDefaultRenderer();
            }
            Component headerComponent = headerRenderer.getTableCellRendererComponent(
                    table, column.getHeaderValue(), false, false, 0, columnIndex);
            int headerWidth = headerComponent.getPreferredSize().width;
            preferredWidth = Math.max(preferredWidth, headerWidth);

            // Calculate preferred width based on cell contents
            for (int rowIndex = 0; rowIndex < table.getRowCount(); rowIndex++) {
                TableCellRenderer cellRenderer = table.getCellRenderer(rowIndex, columnIndex);
                Component cellComponent = table.prepareRenderer(cellRenderer, rowIndex, columnIndex);
                int width = cellComponent.getPreferredSize().width + table.getIntercellSpacing().width;
                preferredWidth = Math.max(preferredWidth, width);
                if (preferredWidth >= maxWidth) {
                    preferredWidth = maxWidth;
                    break;
                }
            }

            column.setPreferredWidth(preferredWidth);
        }
    }
    private void onRowSelected(String dataType) { 
        if (!table.getSelectionModel().getValueIsAdjusting()) {
            int selectedRow = table.getSelectedRow();
            Object selectedValue = table.getValueAt(selectedRow, 1);
            String company = selectedValue.toString();
            if(dataType.equals("Ticket"))
            	displayClients(manager.find(company).getClients());
            if(dataType.equals("Accommodation"))
            	displayClients(manager.getAccommodation(company).getClient());
            System.out.println(company);
        }
    }


    public void displayList(String text, final String type) {
        JFrame frame = new JFrame(type);
        JPanel panel = new JPanel(new GridLayout(0, 1)); // Create a panel with a vertical layout

        String[] items = text.split(","); // Split the text into individual items
        int i = 1;
        for (String item : items) {
            JButton button = new JButton(i + "   " + item.toUpperCase()); // Trim the item to remove leading/trailing spaces
            button.setHorizontalAlignment(SwingConstants.LEADING); // Align text to the start of the line
            i++;
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Button clicked: " + item);
                    String[] AirLine = { "New Ticket", "Delete Ticket" };
                    String[] Accomod = {"New Accommodation", "Cancel"};
                    int choice = 0;
                    if(type.equals("Travel List"))
                        choice = JOptionPane.showOptionDialog(null, "Choose an option", "Air Lines Ticket", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, AirLine, AirLine[0]);
                    if(type.equals("Hotel List"))
                        choice = JOptionPane.showOptionDialog(null, "Choose an option", "Accomodation", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, Accomod, Accomod[0]);
                    if (choice == 0) {
                        if(type.equals("Travel List"))
                        	getClientData(manager.find(item),null);
                        if(type.equals("Hotel List"))
                        	getClientData(null,manager.getAccommodation(item));
                    } else if (choice == 1) {
                        String codeInput;
                        if(type.equals("Air Lines Companies"))
                            codeInput = JOptionPane.showInputDialog(null, "Enter the Ticket ID:", "Delete Ticket", JOptionPane.PLAIN_MESSAGE);
                        else
                            codeInput = JOptionPane.showInputDialog(null, "Enter the Accommodation ID code:", "Delete Ticket", JOptionPane.PLAIN_MESSAGE);
                        if (codeInput != null && !codeInput.isEmpty()){
                            int Code = Integer.parseInt(codeInput);
                            if(type.equals("Travel List"))
                                manager.deleteTicket(Code);
                            else if(type.equals("Hotel List"))
                                manager.deleteAccomodation(Code);
                        }
                    }
                }
            });
            panel.add(button);
        }
        frame.setTitle(type);
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    public void createMenu() {

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10)); // Create a panel with a 2x2 grid layout and spacing
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding to the panel

        JButton button1 = new JButton("Hotel List");
        button1.setPreferredSize(new Dimension(150, 100)); // Set a fixed size for the button
        button1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED)); // Apply a raised beveled border
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	try {
					LeafletMapDisplay.displayAccommodations(manager.getAccommodations());
				} catch (UnsupportedEncodingException e1) { 
					e1.printStackTrace();
				} 
                System.out.println("Accommodation List");
                displayAccommodations(manager.getAccommodations().toArray(new Accommodation[0]));
            }
        });
        panel.add(button1);

        JButton button2 = new JButton("Tickets List");
        button2.setPreferredSize(new Dimension(150, 100)); // Set a fixed size for the button
        button2.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED)); // Apply a raised beveled border
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	try {
					LeafletMapDisplay.displayTicketConnections(manager.getTickets());
				} catch (UnsupportedEncodingException e1) {
					e1.printStackTrace();
				}		
                System.out.println("Tickets List");
                displayTickets(manager.getTickets().toArray(new Ticket[0]));
                
            }
        });
        panel.add(button2);

        JButton button3 = new JButton("New Ticket");
        button3.setPreferredSize(new Dimension(150, 100)); // Set a fixed size for the button
        button3.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED)); // Apply a raised beveled border
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create an array of all points
                HashSet<String> citySet = new HashSet<>();
                for (Ticket t : manager.getTickets()) {
                    String fromCity = t.getFrom();
                    String toCity = t.getTo();
                    citySet.add(fromCity);
                    citySet.add(toCity);
                }
                String[] cities = citySet.toArray(new String[0]);
                JComboBox<String> sourceComboBox = new JComboBox<>(cities);
                JComboBox<String> destinationComboBox = new JComboBox<>(cities);
                JPanel selectionPanel = new JPanel();
                selectionPanel.setLayout(new GridLayout(2, 2));
                selectionPanel.add(new JLabel("Source:"));
                selectionPanel.add(sourceComboBox);
                selectionPanel.add(new JLabel("Destination:"));
                selectionPanel.add(destinationComboBox);
                int result = JOptionPane.showConfirmDialog(null, selectionPanel, "Select Source and Destination", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    String source = (String) sourceComboBox.getSelectedItem();
                    String destination = (String) destinationComboBox.getSelectedItem();
                    System.out.println("Source: " + source);
                    System.out.println("Destination: " + destination);
                    if(manager.isConnected(source,destination) || manager.isConnected(destination,source)){
                         
                        ArrayList<Ticket> avilabelTicket = new ArrayList<Ticket>();
                        StringBuilder accommodations = new StringBuilder();
                        ArrayList<String> connectShort = manager.shortestPath(source, destination);
                        for (int i = 0; i < manager.getTickets().size(); i++) {
                            Ticket ticket = manager.getTickets().get(i);
                            for(int j = 0; j < connectShort.size(); j++) {
                            	String node = connectShort.get(j);
	                            if(ticket.getFrom().equals(node) || ticket.getTo().equals(node) ) {
	                            	accommodations.append(ticket.getCompanyName()).append(",");
	                            	avilabelTicket.add(ticket);
	                            	if(ticket.getTo().equals(destination)) {
	                            		break;
	                            	}
	                                System.out.println("Added");
	                            }
                            }
                        }
                        try {
							LeafletMapDisplay.displayTicketConnections(avilabelTicket);
						} catch (UnsupportedEncodingException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                         displayList(accommodations.toString(), "Travel List");

                    }
                    else{
                        JOptionPane.showMessageDialog(null, (source+" is not connected to "+ destination), "Information", JOptionPane.INFORMATION_MESSAGE);
                        actionPerformed(e);
                    }
                }
            }
        });


        panel.add(button3);

        JButton button4 = new JButton("Accommodations");
        button4.setPreferredSize(new Dimension(150, 100)); // Set a fixed size for the button
        button4.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED)); // Apply a raised beveled border
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	try {
					LeafletMapDisplay.displayAccommodations(manager.getAccommodations());
				} catch (UnsupportedEncodingException e1) { 
					e1.printStackTrace();
				} 
                StringBuilder accommodations = new StringBuilder();
                for (Accommodation a : manager.getAccommodations()) {
                    accommodations.append(a.getCompanyName()).append(",");
                }
                displayList(accommodations.toString(), "Hotel List");
            }
        });
        panel.add(button4);

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setTitle("Menu");
        frame.pack();
        frame.setLocationRelativeTo(null); // Center the frame on the screen
        frame.setVisible(true);
    } 
    private static void getClientData(Ticket company, Accommodation accommodation) {
        // Create the JFrame
        JFrame frame = new JFrame("Client Data"); 
        // Create the panel to hold the components
        JPanel panel = new JPanel();
        
        // Create the text fields and labels for ticket buyer data
        JTextField nameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField phoneField = new JTextField(20);

        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel phoneLabel = new JLabel("Phone:");

        // Create the button to submit the ticket buyer data
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            // Get the entered ticket buyer data
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();    
            if(company != null) {
                JOptionPane.showMessageDialog(frame, "Ticket registered successfully.");         
                boolean o = company.seatBook(name,email,phone);
	            if(!o) {
	            	 JOptionPane.showMessageDialog(null, "No more Seats", "Information", JOptionPane.INFORMATION_MESSAGE);
	            }
            }
            if(accommodation != null) {
                JOptionPane.showMessageDialog(frame, "Accommodation successfully registered");         
            	boolean o = accommodation.bookbed(name,email,phone);
            	if(!o)
            	 JOptionPane.showMessageDialog(null, "No bed avilable", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
            // Reset the text fields
            nameField.setText("");
            emailField.setText("");
            phoneField.setText("");
        });

        // Add the components to the panel
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(submitButton);

        // Add the panel to the frame and display it
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }
     

}
