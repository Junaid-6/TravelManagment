import java.util.ArrayList;

public class Ticket extends Point
{
	protected int code;
	protected String companyName;
	protected String email;
	protected String type;
	protected double price;
	protected Point from;
	protected Point to;  // arriving at
	protected double duration;  // trip duration in hours
	public int maxSeats  = 40;
	ArrayList<Client> clientData = new ArrayList<Client>();

	public Ticket(int c, String cn, String em, String t, double p, Point f, Point to, double dur) {

		if(dur == 0)  dur = 0;
		this.code = c;
		this.companyName = cn;
		this.email = em;
		this.type = t;
		this.price = p;
		this.from = f;
		this.to = to;
		this.duration = dur;
	}

	// gets and sets
	public int getCode() {
		return code;
	}
	public void setCode(int c) {
		this.code = c;
	}
	public String getCompanyName(){
		return companyName;
	}
	public void setCompanyName(String cn) {
		this.companyName = cn;
	}
	public String getEmail(){
		return email;
	}
	public void setEmail(String em) {
		this.email = em;
	}
	public String getType(){
		return type;
	}
	public void setType(String t) {
		this.type = t;
	}
	public double getPrice(){
		return price;
	}
	public void setPrice(double p) {
		this.price = p;
	}
	public double getDestinationLatitude() {
		return to.getLatitude();
	}
	public double getDestinationLongitude(){
		return to.getLongitude();
	}
	public void setFrom(Point from) {
		this.from = from;
	}
	public double getSourceLatitude() {
		return from.getLatitude();
	}
	public  double getSourceLongitude(){
		return from.getLongitude();
	}
	public void setTo(Point to) {
		this.to = to;
	}
	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}


	/**
	 * Get a description of this class as a String
	 */
	public String toString() {
		return "Travel - from: " + from + " to " + to + " - price: " + price;
	}

	public String getFrom() { 
		return from.name;
	}

	public String getTo() { 
		return to.name;
	}
	public Point getToPoint() {
		return this.to.getPoint();
	}
	public Point getFromPoint() {
		return this.from.getPoint();
	}
	public ArrayList<Client> getClients() {
		return this.clientData;
	}
	public boolean seatBook(String name, String email, String phone) {
		if(maxSeats < 0)
			return false;
		maxSeats--;	
		clientData.add(new Client(name,email,phone)); 
		return true;
	}

}
