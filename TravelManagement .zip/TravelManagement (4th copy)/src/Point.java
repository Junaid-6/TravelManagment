public class Point {
    String name;
    double Latitude;
    double Longitude;
    public Point(double Latitude, double Longitude, String name){
        this.Latitude = Latitude;
        this.Longitude = Longitude;
        this.name = name;
    }
    public Point(){
        this.Latitude = 23f;
        this.Longitude = 45f;
        this.name = "Missing";
    }
    public double getLatitude(){
        return this.Latitude;
    }
    public double getLongitude(){
        return this.Longitude;
    }
    public String getName(){
        return  this.name;
    }
    public Point getPoint() {
    	return this;
    }
}
