import java.util.LinkedList;
import java.util.Queue;

public class BinaryTree {

	private Node root; // The root node of the tree
	private int size; // A count of the nodes in the tree

	public BinaryTree(Ticket[] sdtList) {
		root = null;
		size = 0;

		for (Ticket s : sdtList) {
			addNode(s);
		}
	}

	public BinaryTree() {
		root = null;
		size = 0;
	}

	public int size() {
		return size;
	}

	public void clear() {
		root = null;
		size = 0;
	}

	public Node getRoot() {
		return root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	public void addNode(Ticket a) {
		Node node = new Node(a);
		// If tree is empty, make our new node the root and leave
		if (root == null) {
			root = node;
			size = 1;
		} else {
			// Start the recursive calls to add the descendants of node 'p'
			addNode(node, root);
			size = size + 1;
		}

	}
	private void addNode(Node c, Node n) {

		if (c.compareTo(n) < 0) {
			if (n.hasLeft())
				addNode(c, n.left());
			else {

				n.setLeft(c);
				return;
			}
		} else {
			if (n.hasRight())
				addNode(c, n.right());
			else {
				n.setRight(c);
			}
		}
	}

	public String walkTree() {
		StringBuffer buff = new StringBuffer();
		if (root == null)
			return "Empty Tree!";
		else
			walkTree(root, buff);
		return buff.toString();
	}

	protected void walkTree(Node n, StringBuffer sb) {
		if (n == null) {
			return;
		}
		walkTree(n.left(), sb);
		if (n.getNodeObjectName() != null) {
			sb.append(n.getNodeObjectName() + ",");
		}
		walkTree(n.right(), sb);
	}

	
	public Ticket find(String name) {
		return find(name, root);
	}

	protected Ticket find(String name, Node n) {
	    if (n == null) {
	        return null;
	    }
	    
	    int order = name.compareTo(n.getNodeObjectName()); 
	    if (order == 0) {
	        return n.data;
	    } else if (order < 0) {
	        return find(name, n.left());
	    } else {
	        return find(name, n.right());
	    }
	}

	
	public void printTree() {
		printTree(root, 0);
	}

	private void printTree(Node n, int depth) {
		if (n.hasRight())
			printTree(n.right(), depth + 1);
		// Show depth of current code by indenting to the right
		for (int d = 0; d < depth; d++)
			System.out.print("  ");

		System.out.println(n.getNodeObjectName());

		if (n.hasLeft())
			printTree(n.left(), depth + 1);
	}

}
