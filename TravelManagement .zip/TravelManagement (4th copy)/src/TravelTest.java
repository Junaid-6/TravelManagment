
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;

public class TravelTest  {
	Accommodation[] a_list;
	Ticket[] t_list;
	TravelManager manager = new TravelManager();

	GUI gui = new GUI(manager);
	
	public static void main(String[] args) throws UnsupportedEncodingException { 
		TravelTest test = new TravelTest();
		test.go();
	}

	 
	public void loadData() throws UnsupportedEncodingException {
		manager.clear();

		a_list = new Accommodation[]{ new Accommodation(159, "BnB", "contact@bnb.ac.uk", "BnB", 76.50, "London", 2, 51.56071d, -0.26379d),
				new Accommodation(471, "Farmers", "cod@farmers.com", "Hotel", 125.99, "Amsterdam", 4, 32.68708d, -114.62419d),
				new Accommodation(1, "5 Stars", "five@stars.com", "Hotel", 130.90, "Cancun", 2, 23.59269d, 58.39968d),
				new Accommodation(99, "El Rancho", "rancho@hotel.com", "Hotel", 55.50, "Las Vegas", 4, 32.6871284d, -114.6241765d),
				new Accommodation(582, "W Hostel", "public@whostel.com", "Hostel", 35.00, "Paris", 1,34.10095d, -118.32587d),
				new Accommodation(300, "Hyatt", "acc@hyatt.com", "BnB", 199.99, "Dubai", 2, 28.5701546d, 77.1858959d),
				new Accommodation(909, "DnD", "DnDcontact@gmail.com", "Hostel", 39.50, "Bora Bora", 1,28.57412d, 77.31195d),
				new Accommodation(54, "Ritz Hotel", "ritz@hotel.com.br", "Hotel", 15.00, "Rio de Janeiro", 2,35.71357d, 51.40816d),
				new Accommodation(363, "Bliss", "contact@blisshostel.com", "Hostel", 69.99, "Cairo", 2, 6.9032493d, 79.8546167d),
				new Accommodation(764, "Relax Inn", "reservartions@relaxinn.com", "Hotel", 21.50, "Kolkata", 4,20.7185815d, 70.9848973d),
				new Accommodation(973, "Four Seasons", "four@seasons.co.uk", "BnB", 45.90, "Edinburgh", 2,22.28668d,114.15665d),
				new Accommodation(658, "NYNY", "contact@nyny.com", "Hostel", 55.55, "New York", 1,29.2152051d, 79.5324871d),
				new Accommodation(456, "Cape", "rev@cape.com", "Hostel", 49.99, "Doha", 2,6.31184d, -10.81502d),
				new Accommodation(824, "Palazzo", "res@palazzohotel.com", "Hotel", 75.50, "Roma", 2,-26.02491d,28.00994d),
				new Accommodation(630, "Lakes", "lakeshostel@gmail.com", "Hostel", 10.90, "Auckland", 1, -33.9229988d, 151.2064544d),
				new Accommodation(508, "Amsterdam", "contact@denx.hotel.com", "BnB", 65.50, "Amsterdam", 2,42.68107d, 23.35981d),
				new Accommodation(405, "Tower", "contact@tower.com", "Hostel", 75.51, "Johannesburg", 2,51.9364d, 1.27596d),

		};

		t_list = new Ticket[]{
			    new Ticket(147, "Qatar", "contact@qatar.com", "Air", 500.99, new Point(22.31581d, 113.93654d, "Hong_Kong"), new Point(13.8228841d, 100.5320307d, "Bangkok"), 2),
			    new Ticket(565, "KLN", "klm@kln.com", "Air", 1010.25, new Point(27.96734d, 34.41146d, "Amsterdam"), new Point(-22.9068d, -43.1729d, "Rio_de Janeiro"), 11),
			    new Ticket(6542, "Collette", "contact@collette.com", "Train", 231.50, new Point(40.7128d, -74.0060d, "New York"), new Point(36.1699d, -115.1398d, "Las Vegas"), 6),
			    new Ticket(805, "Royal", "contact@royal.co.uk", "Sea", 1505.59, new Point(38.7223d, -9.1393d, "Lisbon"), new Point(31.6295d, -7.9811d, "Marrakech"), 24),
			    new Ticket(100, "RyanAir", "contact@ryanair.com", "Air", 100.99, new Point(52.3667d, 4.8945d, "Amsterdam"), new Point(48.8566d, 2.3522d, "Paris"), 2),
			    new Ticket(753, "Quasar Airlines", "contact@quasar.com", "Air", 90.49, new Point(25.2854d, 51.5310d, "Doha"), new Point(25.2048d, 55.2708d, "Dubai"), 1),
			    new Ticket(888, "M Emirates", "emirates@emirates.com", "Air", 874.10, new Point(25.2048d, 55.2708d, "Dubai"), new Point(31.6295d, -7.9811d, "Marrakech"), 11),
			    new Ticket(001, "Globus", "globus@globus.com", "Train", 250.00, new Point(38.7223d, -9.1393d, "Lisbon"), new Point(48.8566d, 2.3522d, "Paris"), 22),
			    new Ticket(075, "Trafalgar", "contact@trafalgar.com", "Train", 150.25, new Point(48.8566d, 2.3522d, "Paris"), new Point(51.5074d, -0.1278d, "London"), 3),
			    new Ticket(130, "Z Airways", "contact@za.co.uk", "Air", 194.00, new Point(55.8642d, -4.2518d, "Glasgow"), new Point(41.9028d, 12.4964d, "Rome"), 5),
			    new Ticket(010, "KLM", "klm@klm.com", "Air", 95.01, new Point(48.8566d, 2.3522d, "Paris"), new Point(51.5074d, -0.1278d, "London"), 1),
			    new Ticket(101, "MSC", "contact@msc.com", "Sea", 2501.99, new Point(31.6295d, -7.9811d, "Marrakech"), new Point(30.0444d, 31.2357d, "Cairo"), 24*7),
			    new Ticket(654, "British Airways", "contact@ba.co.uk", "Air", 50.50, new Point(51.5074d, -0.1278d, "London"), new Point(55.9533d, -3.1883d, "Edinburgh"), 1),
			    new Ticket(123,"XYZ Airlines","contact@xyzairlines.com","Air", 100.0,new Point(33.6844, 73.0479, "Islamabad"),new Point(24.8607, 67.0011, "Karachi"), 1)       
			     
			};



		manager.addAccommodations(a_list);
		manager.addTickets(t_list);
		
		for(int i = 0; i < manager.getTickets().size(); i++) {
			manager.getTickets().get(i).seatBook("Junaid "+i, "LinuxUbantu@Google.com", "0303"+i+"89"+i+i+"23");
			manager.getTickets().get(i).seatBook("Saeed "+i*i, "MacOS@Google.com", "0334"+i+"11"+i+i+"55");
		}
		for(int i = 0; i < manager.getAccommodations().size(); i++) {
			manager.getAccommodations().get(i).bookbed("Ali "+i, "MacOS@ChatGPT.com", "0303"+i+"89"+i+i+"23");
			manager.getAccommodations().get(i).bookbed("Ozair "+i*i, "Window@ChatGPT.com", "0312"+i+"56"+i+i+"77");
		}
	}

	public void printArrayList(ArrayList<Accommodation> list) {
		for (Accommodation v:list)
			System.out.println(v.toString());
	}

	public void go() throws UnsupportedEncodingException {
		loadData();  
		gui.createMenu();
	}
 
}
