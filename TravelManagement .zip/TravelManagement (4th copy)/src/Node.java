
public class Node {

	Ticket data = null;	// The object stored at this node
	private Node	 left = null;	// The left node of this node
	private Node	 right = null;	// The right node of this node

	public Node(Ticket a)
	{
		data = a;
	}

	public void setLeft(Node n)
	{
		left = n;
	}

	public void setRight(Node n)
	{
		right = n;
	}

	// Get properties of the node
	public Ticket getNodeData() { return data; }
	public String getNodeObjectName() { return data.getCompanyName(); }
	public boolean hasLeft() { return left != null; }
	public boolean hasRight() { return right != null; }
	public Node left() { return left; }
	public Node right() { return right; }
	
	public int compareTo(Node pn) { return getNodeObjectName().compareTo(pn.getNodeObjectName()); }
	public String toString() { return getNodeObjectName(); }
	
}
