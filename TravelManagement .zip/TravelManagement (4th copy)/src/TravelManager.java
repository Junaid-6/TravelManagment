import java.util.ArrayList; 
import java.util.*;


public class TravelManager
{
	private ArrayList<Accommodation> accommodations; // list of accommodations
	private ArrayList<Ticket> tickets;
	private BinaryTree btree; // binary tree that stores the tickets
	private Graph graph;  // graph linking cities covered by the travel tickets
	private ArrayList<String> Hotels;

	public TravelManager()
	{
		accommodations = new ArrayList<Accommodation>();
		tickets	= new ArrayList<Ticket>();
		Hotels = new ArrayList<String>();
		btree = new BinaryTree();
		graph = new Graph();
	}
	public Accommodation getAccommodation(String company) {
		for(int i = 0; i < accommodations.size(); i++) {
			if(accommodations.get(i).getCompanyName().equals(company)) {
				return accommodations.get(i);
			}
		}
		return null;
	}
	public void clear()
	{
		btree.clear();
		accommodations.clear();
		graph = new Graph();
	}
	public ArrayList<String> getHotelsNames(){
		return Hotels;
	}

	public void addAccommodation(Accommodation v)
	{
		accommodations.add(v);
	}

	public ArrayList<Accommodation> getAccommodations()
	{
		return accommodations;
	}

	public void addAccommodations(Accommodation[] v)
	{
		for (Accommodation a : v) {
			accommodations.add(a);
			Hotels.add(a.getCompanyName());
		}
	}
	public boolean deleteAccomodation(int ID){
		for (int i = 0; i < accommodations.size(); i++) {
			Accommodation a = accommodations.get(i);
			if(a.getCode() == ID){
				accommodations.remove(a);
				return true;
			}
		}
		return false;
	}
	public void addTicket(Ticket s)
	{
		tickets.add(s);
		btree.addNode(s);
		graph.insertEdge(s.getFrom()/*source*/, s.getTo()/*Destiny*/);
		graph.insertEdge(s.getTo()/*source*/, s.getFrom()/*Destiny*/);
	}
	public ArrayList<Ticket> getTickets(){
		return tickets;
	}
	public BinaryTree getBtree() {
		return btree;
	}

	public void addTickets(Ticket[] v)
	{
		for (Ticket a : v) {
			tickets.add(a);
			btree.addNode(a);
			graph.insertEdge(a.getFrom(), a.getTo());
			graph.insertEdge(a.getTo(), a.getFrom());
		}
	}
	public  boolean deleteTicket(int code){
		for(int i = 0; i < tickets.size(); i++){
			Ticket t = tickets.get(i);
			if(t.getCode() == code){
				tickets.remove(t);
				return true;
			}
		}
		return false;
	}
	 
	public Graph getGraph()
	{
		return graph;
	}

	public void describe()
	{
		for (Accommodation v : accommodations)
		{
			System.out.println(v.toString());
		}
		btree.printTree();
		System.out.println(graph);
	}

	public String walkTree()
	{
		return btree.walkTree();
	}

	public Ticket find(String name)
	{
		return btree.find(name);
	} 
	public Accommodation findAccommodation(String name) {
		Accommodation a = null;
		for(int i = 0 ; i < getAccommodations().size(); i++) {
			if(getAccommodations().get(i).getCompanyName().equals(name)) {
				a = getAccommodations().get(i);
				break;
			}
		}
		return a;
	}
	public ArrayList<String> shortestPath(String start, String end){
		return getGraph().shortestPath(this,start,end);
	}
	
	public boolean isConnected(String i, String j) {
	    return isConnected(this.graph, i, j);
	}

	public static boolean isConnected(Graph graph, String i, String j) {
	    int startIndex = graph.getVertices().indexOf(i);
	    if (startIndex == -1) {
	        return false; // City i does not exist in the graph
	    }

	    boolean[] visited = new boolean[graph.getVertices().size()];
	    return checkConnection(graph, startIndex, j, visited);
	}

	private static boolean checkConnection(Graph graph, int currentIndex, String j, boolean[] visited) {
	    visited[currentIndex] = true;
	    if (graph.getVertices().get(currentIndex).equals(j)) {
	        return true; // City j is found
	    }

	    LinkedList<String> adj = graph.getAdj(graph.getVertices().get(currentIndex));
	    for (String neighbor : adj) {
	        int index = graph.getVertices().indexOf(neighbor);
	        if (index != -1 && !visited[index]) {
	            if (checkConnection(graph, index, j, visited)) {
	                return true; // City j is found through a neighbor
	            }
	        }
	    }
	    return false; // City j is not found
	}



    public ArrayList<Accommodation> quickSort(boolean asc, String attr)
    {	
    	ArrayList<Accommodation> sorted = new ArrayList<Accommodation>(accommodations);
    	return quickSort(sorted, 0, accommodations.size()-1, asc, attr);
    }
    protected ArrayList<Accommodation> quickSort(ArrayList<Accommodation> list, int low, int high, boolean ascending, String attr)
    {
    	ArrayList<Accommodation> Slist = new ArrayList<Accommodation>();    	 
    	if(attr == "price") {
    		double[] arr = new double[list.size()];
    		int i = 0;
    		for(Accommodation a : list) {
    			arr[i] = a.price;
    			i++;
    		} 
            for (i = 0; i < arr.length; i++) {  
                for (int j = i + 1; j < arr.length; j++) {  
                    double temp = 0;
                    if (!ascending && arr[j] > arr[i]) {      
                        temp =  arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                    else if(ascending && arr[j] < arr[i]){
                    	temp =  arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            for(int k = 0; k < arr.length; k++) {
            	for(Accommodation a : list) {
            		if(arr[k] == a.price) {
            			Slist.add(a);
            		}
            	}
            }
    	}
    	else if ( attr == "name") {
    		String[] arr = new String[list.size()];
    		int i = 0;
    		for(Accommodation a : list) {
    			arr[i] = a.companyName;
    			i++;
    		}
    		for(i = 0; i <arr.length; i++) {
    			for (int j = i + 1; j < arr.length; j++) {  
                    String temp = "";
                    if ( ascending && arr[j].compareTo( arr[i]) < 0) {      
                        temp =  arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                    else if (!ascending && arr[j].compareTo( arr[i]) > 0) {
                    	temp =  arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
    			}
    		}
    		for(int k = 0; k < arr.length; k++) {
            	for(Accommodation a : list) {
            		if(arr[k].compareTo(a.companyName) == 0) {
            			Slist.add(a);
            		}
            	}
            }
    		
    	}
    	return Slist;
    }
	private void Switch(boolean b) {
		
	}
 
}
