
public class Client {
	String name;
	String email;
	String phone;	
	public Client(String name, String email, String phone) {
		this.name = name;
		this.email = email;
		this.phone = phone;
	}
}
