 import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class Graph {
    private ArrayList<LinkedList<String>> adj; // the adjacency list
    private ArrayList<String> vertices; // the list of nodes

    public Graph() {
        adj = new ArrayList<LinkedList<String>>();
        vertices = new ArrayList<String>();
    }

    public ArrayList<String> getVertices() {
        return this.vertices;
    }

    public void insertNode(String i) {
        vertices.add(i);
        adj.add(new LinkedList<String>());
    }

    public void insertEdge(String i, String j) {
        if (vertices.contains(i)) {
            adj.get(vertices.indexOf(i)).add(j);
        } else {
            vertices.add(i);
            adj.add(new LinkedList<String>(Arrays.asList(j)));
        }
    }

    public void removeEdge(String i, String j) {
        if (vertices.contains(i)) {
            adj.get(vertices.indexOf(i)).remove(j);
        }
    }

    public LinkedList<String> getAdj(String i) {
        int index = vertices.indexOf(i);
        if (index != -1) {
            return adj.get(index);
        } else {
            return new LinkedList<String>();
        }
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < vertices.size(); i++) {
            s.append(vertices.get(i) + " -> ");
            for (int j = 0; j < adj.get(i).size(); j++) {
                s.append(adj.get(i).get(j) + " -> ");
            }
            s.append("\n");
        }
        return s.toString();
    }

    public ArrayList<String> shortestPath(TravelManager manager, String start, String end) {
        // Check if start and end vertices exist in the graph
        if (!vertices.contains(start) || !vertices.contains(end)) {
            return new ArrayList<String>(); // Return an empty list if either start or end vertex is not found
        }

        Queue<String> queue = new LinkedList<String>();
        ArrayList<String> visited = new ArrayList<String>();
        ArrayList<String> path = new ArrayList<String>();
        double[] prices = new double[vertices.size()];
        int[] previous = new int[vertices.size()];

        // Initialize prices and previous arrays
        Arrays.fill(prices, Double.POSITIVE_INFINITY);
        Arrays.fill(previous, -1);

        int startIndex = vertices.indexOf(start);
        int endIndex = vertices.indexOf(end);

        queue.add(start);
        visited.add(start);
        prices[startIndex] = 0;

        while (!queue.isEmpty()) {
            String vertex = queue.poll();
            int index = vertices.indexOf(vertex);

            LinkedList<String> neighbors = adj.get(index);
            for (String neighbor : neighbors) {
                int neighborIndex = vertices.indexOf(neighbor);
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                }

                double newPrice = prices[index] + getPrice(manager,vertex, neighbor); // Replace getPrice with your logic to get the price between two vertices
                if (newPrice < prices[neighborIndex]) {
                    prices[neighborIndex] = newPrice;
                    previous[neighborIndex] = index;
                }
            }
        }

        // Build the path from end to start by following the previous array
        int currentIndex = endIndex;
        while (currentIndex != -1) {
            path.add(0, vertices.get(currentIndex));
            currentIndex = previous[currentIndex];
        }

        return path;
    }

    // Helper method to get the price between two vertices
    private double getPrice(TravelManager manager,String start, String end) { 
    	ArrayList<Ticket> tickets = manager.getTickets(); 
        for(int i = 0; i < tickets.size(); i++) {
        	if(tickets.get(i).getFrom().equals(start) && tickets.get(i).getTo().equals(end)) {
        		return  tickets.get(i).getPrice(); 
        	}
        }
        return Double.POSITIVE_INFINITY;
    }
}
