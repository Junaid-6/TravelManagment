				Travel Management

1) Project Description:
	We have made an app that can manage transport and hotel data. We used Data Structures like Graph, Binary Tree, Node, Array List, arrays, and Vectors and some other. Programming Language is Java. We use object oriented programming so data can read and change easily.

2) App:
	it has four functionality it can read hotels list and client in each hostel it also display the location of hostel on map using leaflet we can add new client to the hostel and delete a client.
This can display all the travel path around the globe and the list of companies with other information like prize, company name , start and end point. It also show the information of passenger that are booked for that country it also show position of point on map.

4) Installation and Setup:
	An java JDK 17 or above and web engine like chrome i have attached the source file so you need to import this project it should run if above requirment are full filled(if any issue please feel free to contact me Phone 03110527984 || Gmail : hj03110527984@gmail.com 

5) File Structure:
	All the classes inculding main file are in src directry of project and main class name is Travel Test.
	
6) Documentation:
	Porject contain TravelTest, TravelManager, GUI, Graph, Node, Ticket, Accommodation, Point, Client, Binarytree classes and I have used polymorphism inheritance and composition.

7) Contributing:
	I wanted the GUI to be more attractive and help me to make GUI class more readable.

8) License:
	this project is only be used for learning purpuse and student are strictly forbiden to use this to show to thier instructer.  
